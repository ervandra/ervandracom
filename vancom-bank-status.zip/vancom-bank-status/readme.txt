=== Akismet Anti-Spam ===
Developer: Ervandra Halim, Eddie Zhuo

== Description ==

Vancom Bank Status is a simple plugin to show bank status on your website, based on its online/offline hours.

== Installation ==

Upload the Vancom Bank Status plugin to your blog, Activate it.

1, 2, 3: You're done!

== Changelog ==

= 1.0.0 =
*Release Date - 5 May 2019*

* Initial development
* Support multiple bank entry