<?php
// @codingStandardsIgnoreLine
/*
 * Bank status plugin
 *
 * Plugin Name: Vancom Bank Status
 * Plugin URI:  https://www.ervandra.com
 * Description: Easy to use bank status plugin. Show online/offline banks
 * Version:     1.0.0
 * Author:      Ervandra Halim
 * Author URI:  https://www.ervandra.com
 * License:     GPLv3
 * Copyright:   2019- Ervandra
 * Text Domain: vancom
 * Domain Path: /languages/
 */

function admin_load_js(){
  wp_enqueue_script( 'custom_js', plugins_url( '/js/myplugin.js', __FILE__ ), array('jquery') );
}
// add_action('enqueue_scripts', 'admin_load_js');

function vc_styles(){
  wp_enqueue_style( 'vc-css', plugins_url( '/css/vc.css', __FILE__ ));
}

function vc_scripts() {
	wp_enqueue_script('vc-js', plugins_url( '/js/vc.js', __FILE__ ), array('jquery'));
}

add_action('wp_head', 'vc_styles',5);
add_action('wp_enqueue_scripts', 'vc_scripts');

add_action( 'wp_footer', 'bank_status_content' );

function bank_status_content () {
  $_dir = plugins_url( '/images', __FILE__ );
    $h = "7";// Hour for time zone goes here e.g. +7 or -4, just remove the + or -
    $hm = $h * 60;
    $ms = $hm * 60;
    $time = time()+($ms);
    $day = (int)gmdate("N", $time);
    $hour = (int)gmdate("G", $time);
    $minute = (int)gmdate("i", $time);

    $bca_status = 1;
    $bni_status = 1;
    $bri_status = 1;
    $mandiri_status = 1;


    // bca status
    if($day >= 0 && $day <= 5) {
      if($hour >= 21 || $hour < 1) {
        $bca_status = 0;
      }
    }

    // check bca saturday hour
    if($day === 6) {
      if($hour >= 18 && $hour < 20) {
        $bca_status = 0;
      } else if($hour >= 21) {
        $bca_status = 0;
      }
    }

    //check bca sunday hour
    if($day === 7) {
      if($hour < 5) {
        $bca_status = 0;
      }
    }

    // bri status
    if($hour >= 22 || $hour <= 6) {
      $bri_status = 0;
    }

    // mandiri status
    if($day >= 0 && $day <= 5) {
      if($hour >= 22 && $minute >= 45 || $hour <= 4) {
        $mandiri_status = 0;
      }
    }
    // check mandiri saturday & sunday
    if($day > 5) {
      if($hour >= 22 || $hour <= 5) {
        $mandiri_status = 0;
      }
    }

    echo "<div id='vancom-bank-status'><div class='vc-container'>";

    if($bca_status === 1) {
      echo "<div class='vc-bank-entry vc-online'>";
      echo "<img src='{$_dir}/logo-bca.png' alt='BCA' class='vc-img'/>";
      echo "<span class='vc-text'>Online</span>";
      echo "</div>";
    } else {
      echo "<div class='vc-bank-entry vc-offline'>";
      echo "<img src='{$_dir}/logo-bca.png' alt='BCA' class='vc-img'/>";
      echo "<span class='vc-text'>Offline</span>";
      echo "</div>";
    }

    if($bni_status === 1) {
      echo "<div class='vc-bank-entry vc-online'>";
      echo "<img src='{$_dir}/logo-bni.png' alt='BNI' class='vc-img'/>";
      echo "<span class='vc-text'>Online</span>";
      echo "</div>";
    } else {
      echo "<div class='vc-bank-entry vc-offline'>";
      echo "<img src='{$_dir}/logo-bnk.png' alt='BNI' class='vc-img'/>";
      echo "<span class='vc-text'>Offline</span>";
      echo "</div>";
    }

    if($bri_status === 1) {
      echo "<div class='vc-bank-entry vc-online'>";
      echo "<img src='{$_dir}/logo-bri.png' alt='BRI' class='vc-img'/>";
      echo "<span class='vc-text'>Online</span>";
      echo "</div>";
    } else {
      echo "<div class='vc-bank-entry vc-offline'>";
      echo "<img src='{$_dir}/logo-bri.png' alt='BRI' class='vc-img'/>";
      echo "<span class='vc-text'>Offline</span>";
      echo "</div>";
    }

    if($mandiri_status === 1) {
      echo "<div class='vc-bank-entry vc-online'>";
      echo "<img src='{$_dir}/logo-mandiri.png' alt='Mandiri' class='vc-img'/>";
      echo "<span class='vc-text'>Online</span>";
      echo "</div>";
    } else {
      echo "<div class='vc-bank-entry vc-offline'>";
      echo "<img src='{$_dir}/logo-mandiri.png' alt='Mandiri' class='vc-img'/>";
      echo "<span class='vc-text'>Offline</span>";
      echo "</div>";
    }

    echo "</div></div>";
}
?>